Create table FootBallLeague(
    MatchID int,
    TeamName1 varchar(255),
	TeamName2 varchar(255),
	Status varchar(255),
    WinningTeam varchar(255),
	Point int
);
select * from FootBallLeague;

insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(101,'Italy',	'France',	'Win',	'France',	4);
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1002,'Brazil','Portugal','Draw','null',2 );
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1003,'England','Japan','Win','England',4);	
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1004,'USA','Russia','Win','Russia',4);
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1005,'Portugal','Italy','Draw','null',2);
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1006,'Brazil','France','Win','Brazil',4);
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1007,'England','Russia','Win','Russia',4);
insert into FootBallLeague(MatchID,TeamName1,TeamName2,Status,WinningTeam,Point)values(1008,'Japan','USA','Draw','null',2);

/*StoreProcedure*/

/*Create procedure spFootBallLeagueStore
AS
SELECT * FROM FootBallLeague
GO;*/

spFootBallLeagueStore


/*StoreProcedure for Winning Team Details*/
CREATE PROCEDURE WinningDetailsFottBallLeague
    @Status nvarchar(255)
AS
BEGIN
    SELECT * FROM FootBallLeague
    WHERE Status=@Status
END
GO

EXEC WinningDetailsFottBallLeague @status="Win";





