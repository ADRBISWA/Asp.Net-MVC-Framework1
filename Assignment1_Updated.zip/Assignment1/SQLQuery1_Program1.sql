select * from FootBallLeague;
/*Retriving All Winning Team Data*/
Create Procedure spGetFootBallLeague
AS
BEGIN
	Select WinningTeam from FootBallLeague
end

spGetFootBallLeague

/*View Match Status*/
Create Procedure spGetFootBallLeagueStatus
@Status varchar(255)
as
begin
select MatchId,TeamName1,TeamName2,Status from FootBallLeague where Status= @Status 
end

spGetFootBallLeagueStatus 'Draw'

/*Retrive Data Where all Match japan Played*/
Create Procedure spGetFootBallLeagueJapanPlayed
@TeamName1 varchar(255),
@TeamName2 varchar(255)
as
begin
select TeamName1,TeamName2 from FootBallLeague where TeamName1=@TeamName1 or TeamName2=@TeamName2
end

spGetFootBallLeagueJapanPlayed 'Japan','Japan'